// server.js
// Create a Mongoose schema and insert student records

const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Student = require('./models/studentModel');

dotenv.config();
const app = express();
app.use(express.json());

// ----------------- Connect to MongoDB -----------------
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB connected successfully!'))
  .catch((err) => console.error('❌ MongoDB connection failed:', err.message));

// ----------------- ROUTES -----------------

// Test route
app.get('/', (req, res) => {
  res.send('Mongoose Schema Experiment 🚀');
});

// Insert student records
app.post('/add-student', async (req, res) => {
  try {
    const newStudent = new Student(req.body);
    await newStudent.save();
    res.status(201).json({
      message: 'Student added successfully ✅',
      data: newStudent
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Fetch all students
app.get('/students', async (req, res) => {
  const students = await Student.find();
  res.status(200).json(students);
});

// ----------------- START SERVER -----------------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
